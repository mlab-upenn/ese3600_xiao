# Attribution information for test images

| | |
| :--- | :--- |
| File | person.jpg <br> person_96x96.bmp |
| License | Public Domain |
| Description | Admiral Grace Hopper |
| Link | https://commons.wikimedia.org/wiki/File:Grace_Hopper.jpg |

| | |
| :--- | :--- |
| File | no_person.jpg <br> no_person_96x96.bmp |
| License | Public Domain |
| Description | Giraffe at Nairobi National Park, Kenya |
| Link | https://commons.wikimedia.org/wiki/File:Giraffe_at_Nairobi_National_Park,_Kenya.jpg |
