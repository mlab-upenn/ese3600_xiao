#ifndef TENSORFLOW_LITE_MICRO_ERROR_REPORTER_COMPAT_H_
#define TENSORFLOW_LITE_MICRO_ERROR_REPORTER_COMPAT_H_

#include "tensorflow/lite/micro/tflite_bridge/micro_error_reporter.h"

#endif  // TENSORFLOW_LITE_MICRO_ERROR_REPORTER_COMPAT_H_
