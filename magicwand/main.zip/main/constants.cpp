#include "constants.h"

const char* kGestureLabels[kGestureCount] = {
    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "k", "n", "o", "s"
};

//Change this based on your trained model 