#ifndef MODEL_DATA_H_
#define MODEL_DATA_H_

#include <cstdint>

extern unsigned char g_model[];
extern unsigned int g_model_len;

#endif  // MODEL_DATA_H_
